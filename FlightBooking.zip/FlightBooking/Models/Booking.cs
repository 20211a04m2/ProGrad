﻿namespace FlightBooking.Models
{
    public class Booking
    {
     public int Id { get; set; }
    public string UserId { get; set; }
    public string FlightNumber { get; set; }
    public string Departure { get; set; }
    public string Destination { get; set; }
    public DateTime Date { get; set; }
    public TimeSpan Time { get; set; }
    public User User { get; set; }
    }
}
