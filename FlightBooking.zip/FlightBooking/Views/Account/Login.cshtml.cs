using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FlightBooking.Views.Account
{
    public class AccountModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
