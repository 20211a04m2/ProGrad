using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FlightBooking.Views.Account
{
    public class SignupModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
