﻿using FlightBooking.Data;
using FlightBooking.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Security.Claims;

namespace FlightBooking.Controllers
{
    [Authorize]
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult BookFlight(int flightNumber)
        {
            var flight = _context.Flights.Find(flightNumber);

            if (flight == null)
            {
                return RedirectToAction("Index");
            }

            var viewModel = new Flight
            {
                FlightNumber = flight.FlightNumber,
                DepartureAirport = flight.DepartureAirport,
                ArrivalAirport = flight.ArrivalAirport,
                Price = flight.Price,
                DepartureDateTime = flight.DepartureDateTime,
                ArrivalDateTime = flight.ArrivalDateTime
            };

            return View(viewModel);
        }

        public ActionResult MyBookings()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var bookings = _context.Bookings
                .Where(b => b.UserId == userId)
                .ToList();

            return View(bookings);
        }

        [HttpPost]
        public ActionResult BookFlight(Flight model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }


            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var booking = new Booking
            {
                UserId = userId,
                FlightNumber = model.FlightNumber,
                Departure = model.DepartureAirport,
                Destination = model.ArrivalAirport,
                Date = model.DepartureDateTime.Date,
                Time = model.DepartureDateTime.TimeOfDay
            };

            _context.Bookings.Add(booking);
            _context.SaveChanges();

            return RedirectToAction("BookingSuccess");
        }

        public ActionResult BookingSuccess()
        {
            return View();
        }
    }
}
